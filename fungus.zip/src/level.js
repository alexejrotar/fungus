class Level {
    constructor(grid, molecules) {
        this.grid = grid;
        this.molecules = molecules;
    }


}